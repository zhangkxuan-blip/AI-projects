﻿# 征程手记 · Journey Notes — 设计规范 v2

> 前端实现参考文档 · 薰衣草紫系 · 左右分栏 · 场景叙事

---

## 一、设计理念

**项目本质**：一个带有游戏化兔子互动的治愈系每日任务记录单页应用。  
**核心隐喻**：兔子在场景中陪伴你，努力值驱动场景变化（清晨→星空），而非进度条数字。  
**设计关键词**：治愈、克制、成长感、手绘风、轻量

---

## 二、配色系统

### 2.1 主色系 — 薰衣草紫

| Token | 色值 | 用途 |
|-------|------|------|
| `--c-primary` | `#9B8EC4` | 按钮渐变终点、Tab 激活态、标签背景 |
| `--c-primary-deep` | `#7B6BA6` | 按钮渐变起点、统计数值、深色强调 |
| `--c-primary-light` | `#D4CAEB` | 悬停边框、浅色装饰 |
| `--c-primary-soft` | `#EDE8F5` | Tab 栏背景、柔和底色 |
| `--c-primary-glow` | `rgba(155,142,196,0.35)` | Focus 光环、完成发光 |

### 2.2 背景

| Token | 色值 | 用途 |
|-------|------|------|
| `--bg-page` | `#F5F0FA` | 页面底色 |
| `--bg-card` | `rgba(248,244,252,0.88)` | 卡片底色（毛玻璃） |
| `--bg-card-hover` | `rgba(248,244,252,0.96)` | 卡片悬停 |

### 2.3 点缀色

| Token | 色值 | 用途 |
|-------|------|------|
| `--c-sun` | `#F5D878` | 太阳/暖光、黄色花朵 |
| `--c-peach` | `#E8C8B8` | 暖色点缀 |
| `--c-pink` | `#E8B0C8` | 粉色花朵、腮红、蘑菇 |
| `--c-apricot` | `#E0D0C0` | 暖棕点缀 |

### 2.4 中性色

| Token | 色值 | 用途 |
|-------|------|------|
| `--c-text` | `#4A3F48` | 正文 |
| `--c-text-secondary` | `#8B7B88` | 次要文字、辅助说明 |
| `--c-border` | `#D4C8D8` | 边框、Placeholder |
| `--c-divider` | `rgba(190,176,200,0.25)` | 分割线、弱边框 |
| `--c-cream` | `#F5F0F8` | 浅底色（热力图空单元格等） |

### 2.5 功能色

| Token | 色值 | 用途 |
|-------|------|------|
| `--c-success` | `#9B8EC4` | 完成状态（与主色同） |
| `--c-alert` | `#F5D878` | 警告/提醒 |
| `--c-milestone` | `#E8B0C8` | 里程碑/成就 |

### 2.6 场景色（7 级动态渐变）

| 等级 | 努力值 | 天空顶 | 天空底 | 地面 | 地面深 | 花朵 | 树比例 | 蘑菇 | 篝火 | 帐篷 | 星星 |
|------|--------|--------|--------|------|--------|------|--------|------|------|------|------|
| 0 清晨 | 0 | `#E8DCF0` | `#F5EEFA` | `#D8CCE0` | `#C8B8D4` | `#D4C5E8` | 0.3 | 0 | 0 | 0 | 0 |
| 1 早上 | 1-30 | `#E0D4EC` | `#F2EAF8` | `#D4C8DC` | `#C4B4D0` | `#C8B8E0` | 0.5 | 0 | 0 | 0 | 0 |
| 2 上午 | 31-60 | `#D4C8E8` | `#EEE4F6` | `#D0C4D8` | `#BEB0CC` | `#BEB0DA` | 0.7 | 0 | 0 | 0 | 0 |
| 3 正午 | 61-100 | `#C8B8E4` | `#E8DCF4` | `#CCC0D4` | `#B8A8C8` | `#B5A6D4` | 1.0 | 0.6 | 0 | 0 | 0 |
| 4 午后 | 101-150 | `#BCACE0` | `#E0D4F0` | `#C8B8D0` | `#B0A0C4` | `#A898D0` | 1.2 | 1 | 0 | 0 | 0 |
| 5 日落 | 151-200 | `#A898D0` | `#D0C4E4` | `#C4B4CC` | `#A898BC` | `#9B8EC4` | 1.3 | 1 | 1 | 0 | 0.3 |
| 6 星空 | 200+ | `#2D2848` | `#3D3860` | `#B8A8C4` | `#A090B0` | `#9B8EC4` | 1.4 | 1 | 1 | 1 | 1 |

> **实现方式**：CSS Variables 由 JS 动态 setProperty，天空/地面用 `transition: background 1.2s` 平滑过渡。  
> 天体（太阳/月亮）根据 level 切换渐变色和光晕。

### 2.7 热力图色阶

| 努力值区间 | 色值 |
|-----------|------|
| 0 | `#F5F0F8`（空） |
| 1-30 | `#E0D4F0` |
| 31-60 | `#C8B8E4` |
| 61-100 | `#A898D0` |
| 101-150 | `#8B78BC` |
| 151-200 | `#7B6BA6` |
| 200+ | `#6B5898` |

---

## 三、字体系统

### 3.1 字体家族

| Token | 字体栈 | 用途 |
|-------|--------|------|
| `--font-title` | `'Noto Serif SC', 'Source Han Serif SC', 'SimSun', serif` | 标题、数值、兔子气泡 |
| `--font-body` | `'Inter', 'Noto Sans SC', 'Source Han Sans SC', 'PingFang SC', sans-serif` | 正文、按钮、输入框 |

> ⚠️ 所有字体需确认商用授权。Inter（SIL OFL）、思源系列（SIL OFL）免费商用。SimSun 为系统默认衬线降级。

### 3.2 字号层级

| 层级 | 字号 | 字重 | 用途 |
|------|------|------|------|
| H1 标题 | 28px | 700 | 页面标题「征程手记」 |
| 副标题 | 13px | 400 | 「每一步都算数」 |
| 统计数值 | 24px | 700 | 连续打卡/努力值/累计任务 |
| 统计标签 | 12px | 400 | 数值下方说明 |
| 任务名称 | 14px | 500 | 任务列表项 |
| 任务时间 | 12px | 400 | 任务记录时间 |
| 按钮 | 14px | 600 | 主按钮 |
| Tab | 14px | 500/600 | 切换标签 |
| 兔子气泡 | 14px | 400 | 对话文字 |
| 输入框 | 14px | 400 | 文本输入 |

### 3.3 行高与字间距

| 属性 | 值 |
|------|-----|
| body line-height | 1.6 |
| 标题 letter-spacing | 0.04em |
| 副标题 letter-spacing | 0.08em |

---

## 四、间距系统（8px 栅格）

| Token | 值 | 用途 |
|-------|-----|------|
| `--space-xs` | 4px | Tab 栏内边距 |
| `--space-sm` | 8px | 统计卡片间距、输入区间距、标签内边距 |
| `--space-md` | 16px | 卡片内边距、模块间距、左右分栏 gap |
| `--space-lg` | 24px | 记录板内边距 |
| `--space-xl` | 32px | 大区块间距 |
| `--space-2xl` | 48px | 页面最大宽度内的留白 |

---

## 五、圆角系统

| Token | 值 | 用途 |
|-------|-----|------|
| `--radius-sm` | 6px | 标签、小按钮、蘑菇茎 |
| `--radius-md` | 12px | 卡片、输入框、按钮、气泡、Tab 栏 |
| `--radius-lg` | 18px | 记录板卡片 |
| `--radius-xl` | 24px | 场景舞台 |
| `--radius-full` | 999px | 药丸标签、头像、统计数值装饰 |

---

## 六、阴影系统

| Token | 参数 | 用途 |
|-------|------|------|
| `--shadow-card` | `0 2px 16px rgba(74,60,80,0.06)` | 卡片默认、场景舞台 |
| `--shadow-card-hover` | `0 4px 24px rgba(74,60,80,0.10)` | 卡片悬浮 |
| `--shadow-soft` | `0 1px 4px rgba(74,60,80,0.04)` | 微妙分层 |
| `--shadow-glow` | `0 0 20px rgba(155,142,196,0.35)` | 完成任务发光、focus 光环 |
| 气泡阴影 | `0 2px 12px rgba(0,0,0,0.08)` | 兔子对话气泡 |
| Tab 激活阴影 | `0 1px 4px rgba(0,0,0,0.06)` | 激活 Tab 按钮 |

---

## 七、动效系统

### 7.1 缓动函数

| Token | 贝塞尔曲线 | 用途 |
|-------|-----------|------|
| `--ease-out` | `cubic-bezier(0.4, 0, 0.2, 1)` | 标准过渡（Material 标准） |
| `--ease-bounce` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | 弹性过渡（兔子、场景装饰） |
| `--ease-spring` | `cubic-bezier(0.68, -0.55, 0.27, 1.55)` | 强弹跳（粒子特效） |

### 7.2 动效参数表

| 元素 | 时长 | 缓动 | 说明 |
|------|------|------|------|
| 场景天空/地面变色 | 1.2s | ease-out | 努力值变化时渐变过渡 |
| 树缩放 | 0.8s | ease-bounce | `scale(var(--scene-tree-scale))` |
| 花丛颜色/蘑菇/篝火/帐篷显隐 | 1.2s | ease-out | opacity 过渡 |
| 星星显隐 | 1.5s | ease-out | opacity 过渡 |
| 天体（太阳/月亮） | 1.2s | ease-out | background/box-shadow 过渡 |
| 兔子缩放（hover） | 0.6s | ease-bounce | scale(1.05) |
| 兔子点击反馈 | 0.4s | ease-bounce | scale(0.9) active |
| 兔子弹跳动画 | 0.5s | ease-bounce | 努力值变化时触发 |
| 气泡浮动 | 3s | ease-out | translateY(-3px) 循环 |
| 云朵漂移 | 20-25s | linear | translateX 循环 |
| 星星闪烁 | 3s | ease-out | opacity 0.3↔1 循环 |
| 篝火 flicker | 0.8s | ease-out | scaleY+opacity alternate |
| 帐篷旗帜 | 2s | ease-out | skewY 循环 |
| 花朵摇摆 | 4s | ease-out | rotate(-3deg↔3deg) |
| 标题点脉冲 | 2s | ease-out | opacity+scale 循环 |
| 统计卡片悬停 | 0.3s | ease-out | shadow+border-color |
| Tab 切换面板入场 | 0.3s | ease-out | opacity+translateY(8px→0) |
| Tab 按钮切换 | 0.2s | ease-out | background/color |
| 按钮悬停 | 0.2s | ease-out | transform+shadow |
| 输入框 focus | 0.2s | ease-out | border-color+box-shadow |
| 热力图单元格 | 0.3s | ease-out | background 过渡 |
| 粒子特效 | 0.8s | ease-spring | translate+opacity→0 |
| Toast 提示 | 0.3s | ease-bounce | translateY(-20px→0) 入场 |

---

## 八、图标类型

### 8.1 功能图标（建议 SVG inline，1.5px stroke）

| 场景 | 图标 | 建议图标集 |
|------|------|-----------|
| 添加任务按钮 | ➕ Plus | Lucide `plus` |
| 完成任务 | ✅ Check | Lucide `check` |
| 删除任务 | ✕ X | Lucide `x` |
| 分享按钮 | 🔗 Share / 分支节点 | Lucide `share-2` |
| 连续打卡 | 🔥 Fire | Lucide `flame` |
| 努力值 | ✨ Sparkle | Lucide `sparkles` |
| 累计任务 | 📝 Clipboard | Lucide `clipboard-list` |
| 热力图 | 📊 Grid / Calendar | Lucide `calendar-days` |
| 历史记录 | 📜 Scroll | Lucide `scroll-text` |

### 8.2 状态图标（Emoji，用于空状态）

| 场景 | Emoji |
|------|-------|
| 今日无任务 | 📋 |
| 无历史记录 | 📜 |

### 8.3 场景装饰（纯 CSS 实现，无需图标）

- 太阳/月亮：`border-radius: 50%` + `radial-gradient`
- 云朵：`border-radius: 50%` + `blur(4px)` + white
- 星星：2px 圆点 + twinkle 动画
- 花朵：圆点 + 伪元素茎
- 树：三角形树冠（radial-gradient）+ 矩形树干
- 蘑菇：圆角帽 + 矩形茎
- 篝火：圆木（旋转矩形）+ 火焰（radial-gradient）
- 帐篷：border trick 三角形 + 矩形底座

---

## 九、卡片样式规范

### 9.1 统计卡片（.stat-item）

```css
background: rgba(248,244,252,0.88);
backdrop-filter: blur(12px);
border-radius: 12px;
padding: 16px;
border: 1px solid rgba(190,176,200,0.25);
box-shadow: 0 2px 16px rgba(74,60,80,0.06);
text-align: center;
/* hover → shadow 加深 + border-color 变主色浅色 */
```

### 9.2 记录板卡片（.record-card）

```css
background: rgba(248,244,252,0.88);
backdrop-filter: blur(12px);
border-radius: 18px;
padding: 24px;
border: 1px solid rgba(190,176,200,0.25);
box-shadow: 0 2px 16px rgba(74,60,80,0.06);
```

### 9.3 场景舞台（.stage）

```css
border-radius: 24px;
overflow: hidden;
box-shadow: 0 2px 16px rgba(74,60,80,0.06);
cursor: pointer;
/* 内含天空、地面、装饰元素、兔子，均绝对定位 */
```

### 9.4 任务列表项（.task-item）

```css
display: flex;
align-items: center;
padding: 12px 0;
border-bottom: 1px solid rgba(190,176,200,0.25);
/* 最后一项无 border-bottom */
/* hover 时显示删除按钮（opacity: 0→1） */
```

### 9.5 Tab 栏

```css
display: flex;
background: #EDE8F5;
border-radius: 12px;
padding: 4px;
/* 激活态：白色底 + 主色文字 + 微阴影 */
```

### 9.6 按钮

```css
/* 主按钮（添加任务） */
background: linear-gradient(135deg, #7B6BA6, #9B8EC4);
color: white;
border: none;
border-radius: 12px;
padding: 10px 20px;
font-weight: 600;
/* hover → translateY(-1px) + shadow */

/* 分享按钮 */
background: rgba(248,244,252,0.88);
border: 1.5px solid #D4C8D8;
border-radius: 12px;
color: #4A3F48;
/* hover → border-color 变主色 + shadow */
```

### 9.7 输入框

```css
background: rgba(255,255,255,0.6);
border: 1.5px solid rgba(190,176,200,0.25);
border-radius: 12px;
padding: 10px 14px;
/* focus → border-color: #9B8EC4 + box-shadow: 0 0 0 3px rgba(155,142,196,0.35) */
```

---

## 十、布局规范

### 10.1 桌面端（>860px）— 左右分栏

```
┌──────────────────────────────────────────────┐
│              征程手记 · 每一步都算数           │
├────────────────────┬─────────────────────────┤
│                    │  🔥0  ✨0  📝0          │
│   场景舞台          │  ┌───────────────────┐  │
│   (420×420px)      │  │ 今日征程 | 历史记录 │  │
│                    │  │                   │  │
│   🌤️ 天空          │  │  [输入框] [努力值] │  │
│   ☀️ 太阳          │  │  [+ 添加]         │  │
│   ☁️ 云朵          │  │                   │  │
│   🌳 树            │  │  任务列表...       │  │
│   🌸 花丛          │  │                   │  │
│   🍄 蘑菇          │  └───────────────────┘  │
│   🔥 篝火          │  ┌───────────────────┐  │
│   ⛺ 帐篷          │  │  热力图            │  │
│   🐰 兔子+气泡     │  └───────────────────┘  │
│                    │  [分享我的征程]          │
└────────────────────┴─────────────────────────┘
```

- 左侧固定 420px
- 右侧弹性填充（`flex: 1`）
- 间距 24px

### 10.2 移动端（≤860px）— 上下堆叠

```
┌──────────────────┐
│   征程手记        │
├──────────────────┤
│   场景舞台        │
│   (100%×320px)   │
├──────────────────┤
│  🔥0  ✨0  📝0   │
├──────────────────┤
│  记录板           │
│  ...             │
│  热力图           │
│  [分享]           │
└──────────────────┘
```

### 10.3 页面容器

```css
max-width: 1100px;
margin: 0 auto;
padding: 0 16px;
```

---

## 十一、兔子角色规范

### 11.1 兔子 SVG 结构

```svg
viewBox="0 0 100 100"

图层顺序（从底到顶）：
1. 尾巴 — 右侧 circle r=7, white 70% opacity
2. 左脚 — ellipse rx=10 ry=6, 底部偏左
3. 右脚 — ellipse rx=10 ry=6, 底部偏右
4. 身体 — ellipse cx=50 cy=72 rx=22 ry=20, 主色填充
5. 肚子 — ellipse cx=50 cy=76 rx=14 ry=12, white 60% opacity
6. 左耳 — ellipse rx=9 ry=20, rotate(-10deg)
   内耳 — ellipse rx=5 ry=14, 粉色 opacity 0.35
7. 右耳 — ellipse rx=9 ry=20, rotate(10deg)
   内耳 — ellipse rx=5 ry=14, 粉色 opacity 0.35
8. 脸 — ellipse cx=50 cy=60 rx=20 ry=18, 主色填充
9. 腮红 — ellipse rx=5 ry=3, 粉色 opacity 0.5
10. 眼睛 — ellipse rx=3 ry=3.5, 深色填充
    高光 — circle r=1.2, white
11. 鼻子 — ellipse rx=2.5 ry=2, 粉色填充
12. 嘴巴 — path 弧线, stroke 浅棕
```

### 11.2 兔子颜色

| 部位 | 色值 |
|------|------|
| 身体/脸/耳朵外 | `#F5EDE3` |
| 描边 | `#C8D4E0` |
| 内耳/鼻子/腮红 | `#E8B0C8` |
| 眼睛 | `#4A3F48` |
| 嘴巴线条 | `#B8A0A8` |
| 尾巴 | `white` opacity 0.7 |

### 11.3 兔子状态（表情随努力值变化）

| 努力值 | 状态 | 嘴巴 path | 气泡示例 |
|--------|------|-----------|---------|
| 0 | 😴 发呆 | `M47 66 Q50 68 53 66`（微弧） | 「新的一天，加油！」 |
| 1-30 | 🤔 好奇 | `M47 67 Q50 70 53 67`（小圆口） | 「不错的开始！」 |
| 31-60 | 🙂 微笑 | `M46 66 Q50 71 54 66`（上弧） | 「越来越棒了！」 |
| 61-100 | 😊 开心 | `M46 65 Q50 72 54 65`（大笑） | 「太厉害了！」 |
| 101-150 | 😍 比心 | `M46 65 Q50 72 54 65` + 眼睛变 ❤️ | 「为你骄傲！」 |
| 151-200 | 🎉 庆祝 | `M45 65 Q50 73 55 65`（张嘴） | 「转圈圈庆祝！🎉」 |
| 200+ | 👑 皇冠 | `M45 65 Q50 73 55 65` + 皇冠装饰 | 「👑 王者降临！」 |

> **实现方式**：JS 动态修改 `<path d="...">` 的 d 属性值来切换嘴型。后续 V2 可替换完整 SVG 资源。

---

## 十二、组件状态覆盖

### 12.1 按钮

| 状态 | 样式 |
|------|------|
| default | 渐变紫背景、白色文字 |
| hover | translateY(-1px)、shadow 加深 |
| active/pressed | scale(0.97) |
| disabled | opacity 0.5、cursor not-allowed |

### 12.2 输入框

| 状态 | 样式 |
|------|------|
| default | 半透明白底 + 弱边框 |
| focus | 边框变主色 + 3px glow 光环 |
| placeholder | `color: #D4C8D8` |

### 12.3 Tab 按钮

| 状态 | 样式 |
|------|------|
| default | 透明底、次要文字色 |
| hover | 文字变主色 |
| active | 白底、主色深文字、微阴影、font-weight 600 |

### 12.4 任务列表项

| 状态 | 样式 |
|------|------|
| default | flex 行、底部分割线 |
| completed | 任务名 strikethrough、opacity 0.6 |
| hover | 显示删除按钮（opacity 0→1） |
| 努力值弹跳 | 完成任务时 scale(1.3)→scale(1) 0.4s bounce |

### 12.5 空状态

| 场景 | 显示 |
|------|------|
| 今日无任务 | 📋 图标 + 「今天还没有记录」+ 「写下第一个任务，开始征程吧」 |
| 无历史记录 | 📜 图标 + 「还没有历史记录」+ 「坚持记录，这里会写满你的征程」 |

---

## 十三、数据规范

### 13.1 localStorage 键名

| Key | 格式 | 说明 |
|-----|------|------|
| `journey_tasks` | JSON Array | 所有任务记录 |
| `journey_streak` | JSON Object `{count, lastDate}` | 连续打卡天数 |

### 13.2 任务对象结构

```json
{
  "id": "timestamp_random",
  "date": "2026-05-15",
  "time": "14:30",
  "name": "完成任务名称",
  "effort": 50,
  "completed": true
}
```

### 13.3 分享链接格式

```
https://example.com/share?data={base64编码的摘要JSON}
```

摘要 JSON 结构：
```json
{
  "streak": 7,
  "todayEffort": 150,
  "totalTasks": 42,
  "bunnyMood": "celebrate",
  "date": "2026-05-15"
}
```

---

## 十四、交互清单

| 交互 | 触发条件 | 效果 |
|------|---------|------|
| 添加任务 | 输入名称+努力值 → 点击添加/回车 | 任务入列、兔子探头气泡、列表刷新 |
| 完成任务 | 点击任务勾选框 | 删除线+淡出、努力值累加、数字弹跳、粒子特效、场景升级 |
| 删除任务 | hover 显示 × 按钮 → 点击 | 任务移除、努力值重算、场景降级 |
| 点击兔子/场景 | 点击舞台区域 | 兔子弹跳动画、粒子从点击位置散开 |
| Tab 切换 | 点击「今日征程」/「历史记录」 | 面板滑入切换 |
| 查看热力图 | 切换到历史 Tab → 滚动 | 7列×N行网格、hover 显示日期+努力值 |
| 分享 | 点击分享按钮 | 生成摘要链接、复制到剪贴板、Toast 提示 |
| 每日刷新 | 凌晨 0:00 检测日期变化 | 当日已完成任务保留在历史中、场景重置为清晨、兔子恢复初始 |
| 粒子特效 | 完成任务/点击兔子 | 8-12 个彩色粒子从触发点向四周散开（0.8s 弹簧缓动→消失） |
| Toast | 分享成功/操作反馈 | 底部弹出、3s 后自动消失 |

---

## 十五、可访问性

| 检查项 | 标准 |
|--------|------|
| 正文对比度 | ≥ 4.5:1（`#4A3F48` on `#F5F0FA` ≈ 8.5:1 ✅） |
| 大标题对比度 | ≥ 3:1 ✅ |
| 焦点指示器 | 输入框 focus 有 3px glow 光环 |
| 语义标签 | 使用 `<button>`、`<input>`、`<h1>` 等原生语义元素 |
| 触摸目标 | 按钮 ≥ 44px 可点击区域（移动端） |

---

## 十六、浏览器兼容

| 特性 | 降级方案 |
|------|---------|
| `backdrop-filter: blur()` | Safari 需 `-webkit-backdrop-filter`；不支持时卡片用纯色 `#F8F4FC` |
| CSS Variables | IE11 不支持，现代浏览器全覆盖 |
| SVG inline | 全覆盖 |
| localStorage | 全覆盖 |

---

## 十七、文件结构

```
journey-notes/
├── index.html          # 单文件应用（HTML+CSS+JS）
├── DESIGN-SPEC.md      # 本设计规范文档
└── README.md           # 项目说明
```

> 当前为纯静态单文件，无构建工具依赖。后续如需组件化，可拆分：
> - `bunny.js` — 兔子组件（SVG + 状态机 + 气泡）
> - `scene.js` — 场景渲染（天空/地面/装饰）
> - `tasks.js` — 任务 CRUD + localStorage
> - `heatmap.js` — 热力图组件
> - `particles.js` — 粒子特效
> - `share.js` — 分享链接生成

---

*设计规范 v2 · 薰衣草紫系 · 最后更新 2026-05-15*