#!/usr/bin/env python3
"""
征程手记 · 后端存储服务
存储任务数据到本地文件系统，告别浏览器 localStorage 的脆弱性
"""

import http.server
import json
import os
import re
import urllib.parse
from pathlib import Path

PORT = 5500
DATA_DIR = Path(__file__).parent / "data"
BACKUP_DIR = DATA_DIR / "backups"
TASKS_FILE = DATA_DIR / "journey_tasks.json"
STREAK_FILE = DATA_DIR / "journey_streak.json"
MAX_BACKUPS = 30  # 保留最近 30 份，避免写冲覆盖历史数据
LOCAL_REPO = Path("/home/nami/征程手记")  # 用户本地归档库


def ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def auto_backup():
    """写入前自动备份（去重：仅内容变化 + 有任务数据时才备份）"""
    ensure_data_dir()
    from datetime import datetime

    tasks = read_json(TASKS_FILE, None)
    streak = read_json(STREAK_FILE, None)

    # 没有任务数据时不备份（避免空写冲掉历史）
    if not tasks:
        return

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    # 去重：与最近一次备份比较，内容相同则跳过
    backups = sorted(BACKUP_DIR.glob("auto_*.json"))
    if backups:
        last = json.loads(backups[-1].read_text(encoding="utf-8"))
        last_tasks = sorted([(t.get("date",""), t.get("name",""), t.get("effort",0))
                             for t in last.get("tasks", [])])
        cur_tasks = sorted([(t.get("date",""), t.get("name",""), t.get("effort",0))
                             for t in tasks])
        if last_tasks == cur_tasks:
            return

    backup = {
        "backup_at": datetime.now().isoformat(),
        "tasks": tasks if tasks is not None else [],
        "streak": streak if streak is not None else {"count": 0, "lastDate": ""},
    }
    backup_file = BACKUP_DIR / f"auto_{ts}.json"
    with open(backup_file, "w", encoding="utf-8") as f:
        json.dump(backup, f, ensure_ascii=False, indent=2)

    # 滚动清理
    backups = sorted(BACKUP_DIR.glob("auto_*.json"))
    while len(backups) > MAX_BACKUPS:
        backups[0].unlink()
        backups.pop(0)

    print(f"[BACKUP] → {backup_file.name} ({len(backups)} backups)")


def list_backups():
    """列出所有备份，从新到旧"""
    ensure_data_dir()
    backups = sorted(BACKUP_DIR.glob("auto_*.json"), reverse=True)
    result = []
    for f in backups:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            result.append({
                "file": f.name,
                "time": data.get("backup_at", ""),
                "task_count": len(data.get("tasks", [])),
            })
        except Exception:
            pass
    return result


def restore_from_backup(filename=None):
    """从指定的备份文件恢复，不指定则用最新的"""
    ensure_data_dir()
    backups = sorted(BACKUP_DIR.glob("auto_*.json"))
    if not backups:
        return None

    if filename:
        target = BACKUP_DIR / filename
        if not target.exists():
            return None
    else:
        target = backups[-1]

    data = json.loads(target.read_text(encoding="utf-8"))
    write_json_no_backup(TASKS_FILE, data.get("tasks", []))
    write_json_no_backup(STREAK_FILE, data.get("streak", {"count": 0, "lastDate": ""}))
    return {"file": target.name, "tasks": len(data.get("tasks", []))}


def write_json(filepath, data):
    auto_backup()
    write_json_no_backup(filepath, data)


def write_json_no_backup(filepath, data):
    ensure_data_dir()
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    sync_to_local()  # 每次写入自动同步到用户本地归档库


def read_json(filepath, default=None):
    if default is None:
        default = []
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def sync_to_local():
    """每次数据写入后，自动同步到用户本地归档库 /home/nami/征程手记/"""
    import shutil
    try:
        local_repo = Path("/home/nami/征程手记")
        # 同步代码文件（如果存在且有更新）
        script_dir = Path(__file__).parent
        for fname in ["index.html"]:
            src = script_dir / fname
            dst = local_repo / fname
            if src.exists():
                shutil.copy2(src, dst)
        # 同步数据文件
        local_data = local_repo / "data"
        local_data.mkdir(parents=True, exist_ok=True)
        for fpath in [TASKS_FILE, STREAK_FILE]:
            if fpath.exists():
                shutil.copy2(fpath, local_data / fpath.name)
    except Exception as e:
        print(f"[SYNC] ⚠️ 本地归档同步失败: {e}")




class JourneyHandler(http.server.SimpleHTTPRequestHandler):
    """自定义 HTTP 处理器：静态文件 + REST API"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(Path(__file__).parent), **kwargs)

    def log_message(self, format, *args):
        # 精简日志
        if "/api/" in str(args[0]):
            print(f"[API] {args[0]}")
        else:
            pass  # 忽略静态文件日志

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)

        # ---- API 路由 ----
        if parsed.path == "/api/tasks":
            self._json_response(read_json(TASKS_FILE, []))
            return

        if parsed.path == "/api/streak":
            self._json_response(read_json(STREAK_FILE, {"count": 0, "lastDate": ""}))
            return

        if parsed.path == "/api/health":
            self._json_response({"ok": True, "version": "2.0", "auto_backup": True})
            return

        if parsed.path == "/api/backups":
            self._json_response(list_backups())
            return

        if parsed.path == "/api/export":
            # 导出全部数据为一个 JSON 文件下载
            data = {
                "exported_at": self._now(),
                "tasks": read_json(TASKS_FILE, []),
                "streak": read_json(STREAK_FILE, {"count": 0, "lastDate": ""}),
            }
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="journey_backup.json"')
            self.end_headers()
            self.wfile.write(json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"))
            return

        # ---- 静态文件 ----
        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length else b"{}"

        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            self._error(400, "Invalid JSON")
            return

        if parsed.path == "/api/tasks":
            write_json(TASKS_FILE, payload.get("tasks", []))
            self._json_response({"ok": True, "saved": len(payload.get("tasks", []))})
            return

        if parsed.path == "/api/streak":
            write_json(STREAK_FILE, payload)
            self._json_response({"ok": True})
            return

        if parsed.path == "/api/import":
            # 从备份文件导入
            tasks = payload.get("tasks", [])
            streak = payload.get("streak", {"count": 0, "lastDate": ""})
            write_json_no_backup(TASKS_FILE, tasks)
            write_json_no_backup(STREAK_FILE, streak)
            self._json_response({"ok": True, "tasks": len(tasks)})
            return

        if parsed.path == "/api/restore":
            filename = payload.get("file", None)
            result = restore_from_backup(filename)
            if result is None:
                self._error(404, "No backup found")
            else:
                self._json_response({"ok": True, "restored": result})
            return

        self._error(404, "Not found")

    def _json_response(self, data):
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"))

    def _error(self, code, message):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps({"error": message}, ensure_ascii=False).encode("utf-8"))

    def _now(self):
        from datetime import datetime, timezone, timedelta
        tz = timezone(timedelta(hours=8))
        return datetime.now(tz).isoformat()


if __name__ == "__main__":
    ensure_data_dir()
    print(f"🐰 征程手记后端服务启动")
    print(f"   → 端口: {PORT}")
    print(f"   → 数据目录: {DATA_DIR}")
    print(f"   → 任务文件: {TASKS_FILE}")
    print(f"   → 打卡文件: {STREAK_FILE}")
    print(f"   → 所有数据存储在本地磁盘，不再依赖浏览器 localStorage")
    print()

    server = http.server.HTTPServer(("0.0.0.0", PORT), JourneyHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止")
        server.server_close()