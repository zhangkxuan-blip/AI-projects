# CLAUDE.md — 征程手记 (Journey Notes)

## 项目信息
- **项目名**: 征程手记 (Journey Notes)
- **版本**: v1.0
- **技术栈**: 纯 HTML + CSS + JavaScript 单文件应用
- **无构建工具依赖**, 浏览器直接打开 index.html 即可运行

## 文件结构
```
journey-notes/
├── index.html          # 单文件应用
├── DESIGN-SPEC.md      # 设计规范文档
└── README.md           # 项目说明
```

## 设计规范 (详见 DESIGN-SPEC.md)

### 配色 (薰衣草紫系)
- 主色: `#9B8EC4`, 深紫: `#7B6BA6`, 浅紫: `#D4CAEB`, 柔和紫: `#EDE8F5`
- 背景: `#F5F0FA`, 卡片: `rgba(248,244,252,0.88)` 毛玻璃
- 文本: `#4A3F48`, 次要文本: `#8B7B88`, 边框: `#D4C8D8`
- 点缀: 太阳 `#F5D878`, 粉色 `#E8B0C8`
- 7 级场景渐变色 (清晨→星空)
- 热力图 7 级色阶

### 字体
- 标题: `'Noto Serif SC', serif` (Google Fonts)
- 正文: `'Inter', 'Noto Sans SC', sans-serif` (Google Fonts)
- H1 28px/700, 统计数值 24px/700, 任务名 14px/500, 按钮 14px/600

### 间距: 8px 栅格 (4/8/16/24/32/48)
### 圆角: sm 6px / md 12px / lg 18px / xl 24px / full 999px
### 阴影: 6 组 (card/soft/glow/气泡/Tab)

### 动效
- 缓动: ease-out / ease-bounce / ease-spring
- 场景变色 1.2s, 树缩放 0.8s bounce, 兔子弹跳 0.5s bounce
- 云朵漂移 20-25s linear, 星星闪烁 3s, 粒子 0.8s spring

### 布局
- 桌面 (>860px): 左右分栏, 左 420px 固定, 右弹性
- 移动 (≤860px): 上下堆叠
- 容器 max-width 1100px, 居中

### SVG 兔子 (viewBox 0 0 100 100)
- 10 层结构: 尾巴→脚→身体→肚子→耳朵→脸→腮红→眼睛→鼻子→嘴巴
- 身体 `#F5EDE3`, 描边 `#C8D4E0`, 内耳 `#E8B0C8`, 眼睛 `#4A3F48`
- 7 级嘴型: 微弧→小圆口→上弧→大笑→比心(眼睛变❤️)→张嘴→皇冠

### 场景舞台 (420×420px)
- 天空渐变 7 级 + 太阳/月亮 + 云朵 + 树 + 花丛 + 蘑菇 + 篝火 + 帐篷 + 星星
- 所有装饰元素随努力值动态显隐/变色
- CSS Variables 由 JS setProperty 控制

### 功能清单
1. 添加/编辑/删除任务 (textarea 自适应高度)
2. 任务完成/取消完成
3. Tab 切换 (今日征程 / 历史记录)
4. 统计卡片 (连续天数/努力值/累计任务)
5. 热力图 (7列×N行, hover 显示日期+努力值)
6. SVG 兔子 7 状态 + 对话气泡
7. 场景舞台 7 级渐变
8. 粒子特效 (完成任务/点击兔子)
9. 分享链接生成
10. 每日凌晨自动刷新
11. Toast 提示
12. localStorage 持久化
13. 响应式布局

### 数据存储
- `journey_tasks`: JSON Array [{id, date, time, name, effort, completed}]
- `journey_streak`: JSON Object {count, lastDate}

### 禁止事项
- 禁止执行 `npm run dev` 等阻塞命令
- 禁止使用外部框架/构建工具
- 禁止将密钥/敏感信息写入代码

## 预览方式
项目完成后用 `python3 -m http.server 5500` 启动本地服务预览。
所有样式和逻辑内联在 index.html 单文件中。